#!/bin/sh
./objs/nginx -p .
