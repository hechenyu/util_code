#!/bin/sh
killall -9 nginx
